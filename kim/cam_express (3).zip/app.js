var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var uploadRouter = require('./routes/upload');
var uploadRouter2 = require('./routes/upload2');
var postgresqlloginRouter = require('./routes/login');
var postgresqlsuloginRouter = require('./routes/loginsu');
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));

app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
//app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'routes')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/upload', uploadRouter);
app.use('/upload2', uploadRouter2);
app.use('/login', postgresqlloginRouter);
app.use('/test', require('./routes/test'));
app.use('/management', require('./routes/management'));
app.use('/test2', require('./routes/test2'));
app.use('/gallery', require('./routes/gallery'));
app.use('/signup', require('./routes/signup'));
app.use('/loginsu', require('./routes/loginsu'));
app.use('/login_gallery', require('./routes/login_gallery'));
app.use('/login_photo', require('./routes/login_photo'));
app.use('/login_gallery_move', require('./routes/login_gallery_move'));
app.use('/login_photo_move', require('./routes/login_photo_move'));
app.use('/login_move', require('./routes/login_move'));
app.use('/logout_move', require('./routes/logout_move'));
app.use('/photo_change', require('./routes/photo_change'));
app.use('/photo_change_move', require('./routes/photo_change_move'));
app.use('/test_gallery', require('./routes/test_gallery'));
app.use('/test_photo', require('./routes/test_photo'));
app.use('/change_confirm_password', require('./routes/change_confirm_password'));
app.use('/change_password', require('./routes/change_password'));
// catch 404 and forward to error handler
//app.use(function(req, res, next) {
//  next(createError(404));
//});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;

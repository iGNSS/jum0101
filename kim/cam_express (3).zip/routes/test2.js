var express = require('express');
var router = express.Router();
var static = require('serve-static');
const cors = require('cors');
const results =[];
router.use(cors());
var path = require("path");
router.use(static(path.join(__dirname, 'img')));
router.get('/', (req, res, next) => {
  res.render('test2');
});

//r//outer.get('/preview', async (req, res, next)=>{
///	const imgUrl = "http://10.10.10.162:7220/images/"
//	result = imgUrl+"저장된 이미지명" //imgUrl+"kitty.png"
//	res.send(result); 
//});

//});

module.exports = router;

var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');
const { Client } = require("pg");
const url = require('url');
const cors = require('cors')
const session = require('express-session')
var cookieParser = require('cookie-parser');
router.use(cors({
  origin: true,
  credentials: true
}))
router.use(cookieParser());
router.use(
  session({
    key: "loginData",
    secret: "testSecret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      expires: 60 * 60 * 24,
    },
  })
);
router.get('/', function (req, res, next) {
  var userid = req.cookies.jsonid;
  if (userid != null) {
  res.render('change_confirm_password', { userid: userid.id });
} else {
  res.redirect('/login');
}
});
router.post('/', function (req, res) {
  const dbClient = new Client({
    user: "minuk",
    host: "gw.nineone.com",
    database: "picmonitoring",
    password: "minuk7210",
    port: 5432
  });
  dbClient.connect(err => {
    if (err) {
      console.error('connection error', err.stack)
    } else {
      console.log('change_confirm_password!')
    }
  }); 
  console.log("123")
  var userid = req.cookies.jsonid.id;
  console.log(userid)
  var pw = req.body.pwl
  console.log(pw)
  console.log("2");



  if (pw.length > 0){
   
    console.log("4");
      const query = "SELECT * FROM cam_id_passward WHERE user_id = $1";
      const values = [userid];
      console.log(userid+"4");
      dbClient.query(query, values).then(ress => {
        const data = ress.rows;
        var rows = [];
        if (data.length > 0) {
          data.forEach(row => {
            rows.push(row);
            console.log(row)
          });
          const post = ress.rows[0].user_passward;
          const postInString = JSON.stringify(post);
          console.log(post + "," + pw);
          const match = bcrypt.compareSync(pw, post);
          if (match) {
            console.log("비밀번호 있음");
            idlen = data.length;
            console.log(data + "," + data.length)
            if (data.length >= 1) {
              var expiryDate = new Date(Date.now() + 60 * 60 * 1000 * 24 * 7); // 24 hour 7일
        
        
              dbClient.end();
              // req.session.userid = userid;
              // var cookieLoginObj1 = req.cookies;
              // console.log(req.cookies.json)
              console.log("로그인성공")

              res.redirect('/change_password');

            } else {
              res.redirect('/change_confirm_password?msg=등록되지 않은 사용자 입니다');
              console.log("로그인실패 아이디없음")
              //   dbClient.end();
            }
          } else {
            //   dbClient.end();
            res.send('<script type="text/javascript">alert("로그인실패 아이디 또는 패스워드가 틀림");location.href  ="/change_confirm_password";</script>');
            console.log("로그인실패 아이디 또는 패스워드가 틀림")
          }
        } else {
          //  dbClient.end();
          res.send('<script type="text/javascript">alert("아이디 없음");location.href  ="/change_confirm_password";</script>');
          console.log("아이디 없음")
        }

      });
  }
  // iderrmessge();
  if (userid.length < 2 || userid.length >= 10) {
    // res.send("<script>alert('알림 창입니다.');</script>");
    console.log("22");

    //res.status(200).send({message : '성공'});
  } else {
     console.log("23");

    //	res.send('<script type="text/javascript">alert("오류발생");history.go(-1);</script>');
    // res.status(200).send({message : '성공'});
  }
  console.log("3");

});
module.exports = router;

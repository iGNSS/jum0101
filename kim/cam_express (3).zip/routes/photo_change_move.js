var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');
const { Client } = require("pg");
const url = require('url');
const fs = require('fs');
const cors = require('cors')
const session = require('express-session')
var cookieParser = require('cookie-parser');
router.use(cookieParser());
router.use(
  session({
    key: "loginData",
    secret: "testSecret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      expires: 60 * 60 * 24,
    },
  })
);

router.get('/', function (req, res, next) {
  var device_id = req.query.de_id;
  var change_name = req.query.change_name;
  var change_date = req.query.change_date;
  const change_parse = Date.parse(change_date);
  const KR_TIME_DIFF = 9 * 60 * 60 * 1000;
  const chnage_time =  new Date(change_parse-(KR_TIME_DIFF));
  const dbClient = new Client({
    user: "minuk",
    host: "gw.nineone.com",
    database: "picmonitoring",
    password: "minuk7210",
    port: 5432
  });
  /* res.cookie('jsondevide', {
     deviceid: req.query.de_id,
     name: 'mingyu',
     data: 100
   });*/
  console.log("photo_change_move_start")
  console.log(change_date +" 1")
  console.log(change_parse+ " 2")
  console.log(chnage_time+ " 3");
  dbClient.connect(err => {
    if (err) {
      console.error('connection error', err.stack)
    } else {
      console.log('success!')
    }
  });
  const sqlupload = `UPDATE cam_photo_recent SET photo_file_name = $1, photo_file_date = $2 WHERE device_id = $3`;
  const sqluploadvalues = [change_name, chnage_time ,device_id];
  dbClient.query(sqlupload, sqluploadvalues, (err, res3) => {
    if (err) {
      dbClient.end();
      console.log(err.stack)
      //res.render('photo_change_move', { device_name: device_name });
    } else {

      dbClient.end();
      console.log(res3.rows[0])

      res.render('photo_change_move');
    }

  });


});

module.exports = router;

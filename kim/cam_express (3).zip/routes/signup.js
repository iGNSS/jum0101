var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var path = require("path");
const bcrypt = require('bcrypt');


const { Client } = require("pg");
const dbClient = new Client({
  user: "minuk",
  host: "gw.nineone.com",
  database: "picmonitoring",
  password: "minuk7210",
  port: 5432
});

console.log("123")
router.get('/', function (req, res, next) {

  res.render('signup');

});

var idlen;
router.post('/', function (req, res) {
  dbClient.connect();
  var id = req.body.idd
  var pw = req.body.pw
  var cpw = req.body.cpw
  var mid = req.body.mid
  var bbb = req.body.overlap
  console.log(id)


  if (process.browser) {
    const name = document.getElementById('idd').value;
    document.getElementById("iderr").innerText = name;
    console.log(3)

  }

  if (bbb == '123456') {
    iderrmessge();
    const query = "SELECT * FROM cam_id_passward WHERE user_id = $1";
    const values = [id];
    dbClient.query(query, values).then(res => {

      const data = res.rows;
      idlen = data.length;
      console.log(data + "," + data.length)
      if (data.length >= 1) {
        console.log("아이디 중복")
        iderrmessge();
      } else {
        console.log("아이디 사용가능")
        iderrmessge();
      }
      data.forEach(row => console.log(row));
    });
  }
  // iderrmessge();
  if (id.length > 1 && cpw.length > 1 && mid.length >= 1) {
    const sql = "INSERT INTO cam_id_passward (user_id, user_passward, user_group_id) VALUES($1, $2, $3) RETURNING *";
    const hash = bcrypt.hashSync(cpw, 10);
    const values = [id, hash, mid];
    dbClient.query(sql, values, (err, resp) => {
      if (err) {
        dbClient.end();
        res.send('<script type="text/javascript">alert("아이디 중복");history.go(-1);</script>');
        console.log("아이디 중복")
        res.render('signup.js',{'failID': "아이디 중복"})
        console.log(err.stack)
      } else {
        dbClient.end();
        res.send('<script type="text/javascript">alert("성공");window.location = "/login";</script>');
        console.log(resp.rows[0])
      }
    });
  } else {
    console.log("회원가입 실패")
  }
  if (id.length < 2 || id.length >= 10) {
    // res.send("<script>alert('알림 창입니다.');</script>");
    //console.log(id);

    //res.status(200).send({message : '성공'});
  } else {
    // console.log("2");
    //	res.send('<script type="text/javascript">alert("오류발생");history.go(-1);</script>');
    // res.status(200).send({message : '성공'});
  }
  console.log("3");
});

function iderrmessge() {

  if (typeof document !== "undefined") {
    let x = document.getElementsByClassName("idd")[0];
    // x.innerText="Javascript"; 
    x.style.color = "red";
    document.getElementById('iderr').innerHTML = '아이디';
  }
  if (idlen >= 1) {
    if (typeof document !== "undefined") {
      document.getElementById('iderr').innerHTML = '아이디 중복';
    }
  } else {
    console.log("아이디 사용가능")
    if (typeof document !== "undefined") {
      document.getElementById('iderr').innerHTML = '아이디 사용가능';
    }

  }
}
router.get('/signup2', function (req, res, next) {
  //  console.log("3");
  res.render('signup2');
});
function checkPW() {
  //  $('#id').val();
  const id = req.body.idd
  const pw = req.body.pw
  const cpw = req.body.cpw
  const mid = req.body.mid
  console.log("r3");
  if (id.length == 0) {

  }
  else if (id.length < 2 || id.length >= 10) {
    alert("ID는 2~10글자");
  } else {
    `<script>
    alert('이메일 인증 시간을 초과했습니다.');
  
  </script>`
  }
}
module.exports = router;

var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');
const { Client } = require("pg");
const url = require('url');
const fs = require('fs');
const cors = require('cors')
const session = require('express-session')
var cookieParser = require('cookie-parser');
router.use(cookieParser());
router.use(
  session({
    key: "loginData",
    secret: "testSecret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      expires: 60 * 60 * 24,
    },
  })
);

router.get('/', function (req, res, next) {

  const passedLists = req.cookies.jsonid;
  res.clearCookie('jsonName');
  console.log(passedLists + "dd");
  if (passedLists != null) {
    // const passedLists = req.query;
    const dbClient = new Client({
      user: "minuk",
      host: "gw.nineone.com",
      database: "picmonitoring",
      password: "minuk7210",
      port: 5432
    });
    /*res.cookie('jsondevide', {
       deviceid: req.query.de_id,
       name: 'mingyu',
       data: 100
     });*/

    dbClient.connect(err => {
      if (err) {
        console.error('connection error', err.stack)
      } else {
        console.log('success!')
      }
    });
    //var paths = [];;
    const passed_device_id = req.cookies.jsondevideID;
    if (passed_device_id != null) {
      var deive_id = passed_device_id.deviceid;
      const folder = 'routes/uploads/' + deive_id + "/";

      /* fs.readdir(folder, function (error, filelist) {
         console.log(filelist);
         //paths=filelist;
       });
       fs.readdir(folder, (err, filelist) => { // 하나의 데이터씩 나누어 출
         filelist.forEach(file => {
           console.log(file);
           paths.push('uploads/' + deive_id + "/" + file);
         })
   
       })*/
      console.log(passedLists);
      const cam_id_passward_query = "SELECT * FROM cam_id_passward WHERE user_id = $1";
      const id_passward_values = [passedLists?.id];

      dbClient.query(cam_id_passward_query, id_passward_values).then(res2 => {
        const cam_id_passward_data = res2.rows;
        var id_passward_rows = [];

        if (cam_id_passward_data.length > 0) {
          cam_id_passward_data.forEach(data_row1 => {

            id_passward_rows.push(data_row1);

          });
          const group_id = res2.rows[0].user_group_id;
          //const postInString = JSON.stringify(post);
          console.log('loginsu')

          const cam_device_id_query = "SELECT * FROM cam_photo_file where device_id = $1 order by photo_file_day DESC";
          const device_id_values = [deive_id];
          dbClient.query(cam_device_id_query, device_id_values).then(res3 => {
            const cam_device_id_data = res3.rows;
            var device_id_rows = [];
            var device_date_rows = [];
            var paths = [];;
            if (cam_device_id_data.length > 0) {
              cam_device_id_data.forEach(data_row2 => {
                var today = data_row2.photo_file_day;
                var year = today.getFullYear(); // 년도
                var month = today.getMonth() + 1;  // 월
                var date = today.getDate();  // 날짜
                var day = today.getDay();
                var hours = today.getHours(); // 시
                var minutes = today.getMinutes();  // 분
                var seconds = today.getSeconds();  // 초
                var milliseconds = today.getMilliseconds();
                var dateString = year + '.' + month + '.' + date + " " + hours + ':' + minutes + ':' + seconds;
                var file = data_row2.photo_file_name;
        
                paths.push('uploads/' + deive_id + "/" + file);

                device_id_rows.push(data_row2);
                device_date_rows.push(dateString);
          

              });

            }
            res.render('login_gallery', { imgs: paths, layout: false, group_id: group_id, device_id: device_id_rows, device_date: device_date_rows });
          });


          //dbClient.end();

        } else {
          console.log('0')
          res.render('login');
          //dbClient.end();
        }
      });
      // dbClient.end();

    }else{
      res.redirect('/loginsu');
    }
  } else {
    res.redirect('/login');
  }
});

module.exports = router;

var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');
const url = require('url');
const fs = require('fs');
const cors = require('cors')
const session = require('express-session')
var cookieParser = require('cookie-parser');
router.use(cookieParser());
router.use(
  session({
    key: "loginData",
    secret: "testSecret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      expires: 60 * 60 * 24,
    },
  })
);

router.get('/', function (req, res, next) {
 
  
  res.render('login_move');
      
});

module.exports = router;

var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');
const { Client } = require("pg");
const url = require('url');
const fs = require('fs');
const cors = require('cors')
const session = require('express-session')
var cookieParser = require('cookie-parser');
router.use(cookieParser());
router.use(
  session({
    key: "loginData",
    secret: "testSecret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      expires: 60 * 60 * 24,
    },
  })
);

router.get('/', function (req, res, next) {

  const passedLists = req.cookies.jsonid;
  console.log(passedLists + "dd");
  if (passedLists != null) {
    // const passedLists = req.query;
    const dbClient = new Client({
      user: "minuk",
      host: "gw.nineone.com",
      database: "picmonitoring",
      password: "minuk7210",
      port: 5432
    });


    dbClient.connect(err => {
      if (err) {
        console.error('connection error', err.stack)
      } else {
        console.log('success!')
      }
    });
    var paths = [];;
    var deive_id = req.query.de_id;
    const folder = 'routes/uploads/0000000025f18cbf/';

    fs.readdir(folder, function (error, filelist) {
      console.log(filelist);
      //paths=filelist;
    });
    fs.readdir(folder, (err, filelist) => { // 하나의 데이터씩 나누어 출
      filelist.forEach(file => {
        console.log(file);
        paths.push('uploads/0000000025f18cbf/' + file);
      })

    })
    console.log(passedLists);
    const cam_id_passward_query = "SELECT * FROM cam_id_passward WHERE user_id = $1";
    const id_passward_values = [passedLists?.id];

    dbClient.query(cam_id_passward_query, id_passward_values).then(res2 => {
      const cam_id_passward_data = res2.rows;
      var id_passward_rows = [];

      if (cam_id_passward_data.length > 0) {
        cam_id_passward_data.forEach(data_row1 => {

          id_passward_rows.push(data_row1);
          console.log(data_row1)

        });
        const group_id = res2.rows[0].user_group_id;
        //const postInString = JSON.stringify(post);
      
        console.log('loginsu')

        var cam_photo_name1;
        var cam_photo_day1;
        const cam_photo_recent_query = "SELECT * FROM cam_photo_recent WHERE device_id = $1";
        const cam_photo_recent_values = ["0000000025f18cbf"];
        dbClient.query(cam_photo_recent_query, cam_photo_recent_values).then(res3 => {
          const cam_photo_recent_data = res3.rows;
       
          //console.log(photo_file_name)
          //var cam_photo_name1 = 'uploads/0000000025f18cbf/' + photo_file_name;
          //console.log(cam_photo_name1)

          var device_id_rows = [];
          if (cam_photo_recent_data.length > 0) {
              cam_photo_recent_data.forEach(data_row2 => {
    
              device_id_rows.push(data_row2);
              cam_photo_name1 = device_id_rows[0].photo_file_name;
              cam_photo_day1 = device_id_rows[0].photo_file_date;
              console.log(cam_photo_name1)

            });//select * from(select * from a(테이블) order by 날짜컬럼 DESC) where ROWNUM = 1
           
            console.log("15")
            //const cam_photo_file_query = "SELECT * FROM cam_photo_file WHERE device_id = $1";
            const cam_photo_file_query = "SELECT * FROM cam_photo_file order by photo_file_day DESC";
    
            dbClient.query(cam_photo_file_query).then(res4 => {
              console.log(res4.rows[0].photo_file_name)
              var cam_photo_name2 =  res4.rows[0].photo_file_name;
              var cam_photo_day2 =  res4.rows[0].photo_file_day;
              res.render('test_photo', {device_id: "0000000025f18cbf", cam_photo_name1: cam_photo_name1, cam_photo_name2: cam_photo_name2, cam_photo_day1:cam_photo_day1,cam_photo_day2:cam_photo_day2 });
      
            });
          }
         });

        //dbClient.end();

      } else {
        console.log('0')
        res.render('login');
        //dbClient.end();
      }
    });
    // dbClient.end();


  } else {
    res.render('login');
  }
});

module.exports = router;

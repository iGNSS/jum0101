var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');
const { Client } = require("pg");
const url = require('url');
const cors = require('cors')
const session = require('express-session')
var cookieParser = require('cookie-parser');
router.use(cors({
  origin: true,
  credentials: true
}))
router.use(cookieParser());
router.use(
  session({
    key: "loginData",
    secret: "testSecret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      expires: 60 * 60 * 24,
    },
  })
);
router.get('/', function (req, res, next) {
  res.render('login');
});
router.post('/', function (req, res) {
  const dbClient = new Client({
    user: "minuk",
    host: "gw.nineone.com",
    database: "picmonitoring",
    password: "minuk7210",
    port: 5432
  });
  dbClient.connect(err => {
    if (err) {
      console.error('connection error', err.stack)
    } else {
      console.log('success2!')
    }
  });
  var userid = req.body.iddl
  var pw = req.body.pwl
  var bbb = req.body.btul

  console.log(userid)


  if (userid.length > 0 && pw.length > 0){
    if (bbb == '123456') {

      //const query = "SELECT * FROM cam_id_passward WHERE user_id = $1 AND user_passward = $2";
      const query = "SELECT * FROM cam_id_passward WHERE user_id = $1";
      const values = [userid];
      dbClient.query(query, values).then(ress => {
        const data = ress.rows;
        var rows = [];
        if (data.length > 0) {
          data.forEach(row => {
            rows.push(row);
            console.log(row)
          });
          const post = ress.rows[0].user_passward;
          const postInString = JSON.stringify(post);
          console.log(post + "," + pw);
          const match = bcrypt.compareSync(pw, post);
          if (match) {
            console.log("비밀번호 있음");
            idlen = data.length;
            console.log(data + "," + data.length)
            if (data.length >= 1) {
              var expiryDate = new Date(Date.now() + 60 * 60 * 1000 * 24 * 7); // 24 hour 7일
              /* req.session.loginsu = {
                 ids: id,
               };
               var cookieLoginObj1 = req.session.loginsu //암호화된 쿠키*/
              res.cookie('jsonid', {
                id: userid,
                name: 'mingyu',
                data: 100
              });
              dbClient.end();
              // req.session.userid = userid;
              // var cookieLoginObj1 = req.cookies;
              // console.log(req.cookies.json)
              console.log("로그인성공")

              res.redirect('/login_move');

              /*res.redirect(url.format({
                pathname:"/loginsu",
                query: {
                  "id": cookieLoginObj1.id
                }
              }));*/
              // res.writeHead(200, { "Content-Type": "text/html; charset=utf8" });
              // res.write("<h1>Login Success</h1>");
              // res.write(`[ID] : ${id} [PW] : ${pw}`);
              // res.write('<meta http-equiv="refresh" content="0; URL=/loginsu">');
              //res.write('<a href="/loginsu">Move</a>');
              // res.end();

            } else {
              res.redirect('/login?msg=등록되지 않은 사용자 입니다');
              console.log("로그인실패\n등록된")
              //   dbClient.end();
            }
          } else {
            //   dbClient.end();
            res.send('<script type="text/javascript">alert("로그인실패 아이디 또는 패스워드가 틀립니다");location.href  ="/login";</script>');
            console.log("로그인실패 아이디 또는 패스워드가 틀림립니다.")
          }
        } else {
          //  dbClient.end();
          res.send('<script type="text/javascript">alert("아이디 없습니다.");location.href  ="/login";</script>');
          console.log("아이디 없음습니다.")
        }

      });
    }
  }
  // iderrmessge();
  if (userid.length < 2 || userid.length >= 10) {
    // res.send("<script>alert('알림 창입니다.');</script>");
    //console.log(id);

    //res.status(200).send({message : '성공'});
  } else {
    // console.log("2");

    //	res.send('<script type="text/javascript">alert("오류발생");history.go(-1);</script>');
    // res.status(200).send({message : '성공'});
  }
  console.log("3");

});
module.exports = router;

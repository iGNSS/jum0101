var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');
const { Client } = require("pg");
const url = require('url');
const cors = require('cors')
var cookieParser = require('cookie-parser');
const session = require('express-session')
router.use(cors({
  origin: true,
  credentials: true
}))
router.use(cookieParser());
router.use(
  session({
    key: "loginData",
    secret: "testSecret",
    resave: true,
    saveUninitialized: true,
    cookie: {
      expires: 60 * 60 * 24,
    },
  })
);
router.get('/', function (req, res, next) {

  const dbClient = new Client({
    user: "minuk",
    host: "gw.nineone.com",
    database: "picmonitoring",
    password: "minuk7210",
    port: 5432
  });
  dbClient.connect(err => {
    if (err) {
      console.error('connection error', err.stack)
    } else {
      console.log('success!')
    }
  });
  //const passedLists = req.query;
  //var passedLists = req.session.loginsu;
  const passedLists = req.cookies.jsonid;

  if (passedLists != null) {
    console.log(passedLists.id + " su")
    const cam_id_passward_query = "SELECT * FROM cam_id_passward WHERE user_id = $1";
    const id_passward_values = [passedLists.id];

    dbClient.query(cam_id_passward_query, id_passward_values).then(res2 => {
      const cam_id_passward_data = res2.rows;
      var id_passward_rows = [];

      if (cam_id_passward_data.length > 0) {
        cam_id_passward_data.forEach(data_row1 => {

          id_passward_rows.push(data_row1);
          console.log(data_row1)

        });
        const group_id = res2.rows[0].user_group_id;
        //const postInString = JSON.stringify(post);
        console.log(group_id);
        console.log('loginsu')


        const cam_device_id_query = "SELECT * FROM cam_device_id WHERE group_id = $1";
        const device_id_values = [group_id];
        dbClient.query(cam_device_id_query, device_id_values).then(res3 => {
          const cam_device_id_data = res3.rows;
          var device_id_rows = [];
          var device_date_rows = [];
          if (cam_device_id_data.length > 0) {
            cam_device_id_data.forEach(data_row2 => {
              var today = data_row2.device_time;
              var year = today.getFullYear(); // 년도
              var month = today.getMonth() + 1;  // 월
              var date = today.getDate();  // 날짜
              var day = today.getDay();
              var hours = today.getHours(); // 시
              var minutes = today.getMinutes();  // 분
              var seconds = today.getSeconds();  // 초
              var milliseconds = today.getMilliseconds();
              var dateString = year + '.' + month + '.' + date + " " + hours + ':' + minutes + ':' + seconds;


              device_id_rows.push(data_row2);
              device_date_rows.push(dateString);
              console.log(dateString)

            });

          }
          res.render('loginsu', { group_id: group_id, user_id: passedLists.id, device_id: device_id_rows, device_date: device_date_rows });
        });


        //dbClient.end();

      } else {
        console.log('0')
        res.render('loginsu');
        //dbClient.end();
      }
    });
    // dbClient.end();
  }else{
    res.redirect('/login');
  }
});

module.exports = router;

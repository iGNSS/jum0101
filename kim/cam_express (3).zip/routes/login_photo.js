var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');
const { Client } = require("pg");
const url = require('url');
const fs = require('fs');
const cors = require('cors')
var cookieParser = require('cookie-parser');
const session = require('express-session')
router.use(cors({
  origin: true,
  credentials: true
}))
router.use(cookieParser());
router.use(
  session({
    key: "loginData",
    secret: "testSecret",
    resave: true,
    saveUninitialized: true,
    cookie: {
      expires: 60 * 60 * 24,
    },
  })
);

router.get('/', function (req, res, next) {
  console.log('startphoto!')
  console.log(req.query.de_name+" 1")
//  const photo_name = req.query.de_name;
  if(req.cookies.jsonName === undefined){
    console.log(req.query.de_name+" 2")
    if(req.query.de_name != undefined){
     
     // req.session.num = req.query.de_name;
     console.log(req.cookies.jsonName+" 2")
    }else{
      //res.render('test_photo', {device_id: device_id, cam_photo_name1: cam_photo_name1, cam_photo_name2: cam_photo_name2, cam_photo_day1:cam_photo_day1,cam_photo_day2:cam_photo_day2 });
      res.redirect('/login_gallery');

    }
  } else {
    console.log(req.query.num+"3")
   // req.session.num = req.session.num
  }
  const passed_jsonid = req.cookies.jsonid;
  const passed_device_id = req.cookies.jsondevideID;
  const passed_photo_name = req.cookies.jsonName;
  console.log(passed_photo_name.dename + " dd");
  if (passed_jsonid != null) {
    // const passed_jsonid = req.query;
    const dbClient = new Client({
      user: "minuk",
      host: "gw.nineone.com",
      database: "picmonitoring",
      password: "minuk7210",
      port: 5432
    });


    dbClient.connect(err => {
      if (err) {
        console.error('connection error', err.stack)
      } else {
        console.log('success!')
      }
    });
    var paths = [];;
    var device_id = passed_device_id.deviceid;;
    const folder = 'routes/uploads/0000000025f18cbf/';

    fs.readdir(folder, (err, filelist) => { // 하나의 데이터씩 나누어 출
      filelist.forEach(file => {
  
        paths.push('uploads/0000000025f18cbf/' + file);
      })

    })
    console.log(passed_jsonid);
    const cam_id_passward_query = "SELECT * FROM cam_id_passward WHERE user_id = $1";
    const id_passward_values = [passed_jsonid?.id];

    dbClient.query(cam_id_passward_query, id_passward_values).then(res2 => {
      const cam_id_passward_data = res2.rows;
      var id_passward_rows = [];

      if (cam_id_passward_data.length > 0) {
        cam_id_passward_data.forEach(data_row1 => {

          id_passward_rows.push(data_row1);

        });
        const group_id = res2.rows[0].user_group_id;
        //const postInString = JSON.stringify(post);
      
        console.log('photosu')

        var cam_photo_name1;
        var cam_photo_day1;
        const cam_photo_recent_query = "SELECT * FROM cam_photo_recent WHERE device_id = $1";
        const cam_photo_recent_values = [device_id];
 
        dbClient.query(cam_photo_recent_query, cam_photo_recent_values).then(res3 => {
          const cam_photo_recent_data = res3.rows;
       
          //console.log(photo_file_name)
          //var cam_photo_name1 = 'uploads/0000000025f18cbf/' + photo_file_name;
          //console.log(cam_photo_name1)

          var device_id_rows = [];
          if (cam_photo_recent_data.length > 0) {
              cam_photo_recent_data.forEach(data_row2 => {
    
              device_id_rows.push(data_row2);
              cam_photo_name1 = device_id_rows[0].photo_file_name;
              console.log(device_id_rows[0].photo_file_date)
              var today = device_id_rows[0].photo_file_date;
              var year = today.getFullYear(); // 년도
              var month = today.getMonth() + 1;  // 월
              var date = today.getDate();  // 날짜
              var day = today.getDay();
              var hours = today.getHours(); // 시
              var minutes = today.getMinutes();  // 분
              var seconds = today.getSeconds();  // 초
              cam_photo_day1 = year + '.' + month + '.' + date + " " + hours + ':' + minutes + ':' + seconds;
        
            });//select * from(select * from a(테이블) order by 날짜컬럼 DESC) where ROWNUM = 1
           
            console.log("15")
            const cam_photo_file_query = "SELECT * FROM cam_photo_file WHERE photo_file_name = $1";
            const cam_photo_file_value = [passed_photo_name?.dename];
            dbClient.query(cam_photo_file_query,cam_photo_file_value).then(res4 => {
              console.log(res4.rows[0].photo_file_day)
              var cam_photo_name2 =  res4.rows[0].photo_file_name;
              var today = res4.rows[0].photo_file_day;
              var year = today.getFullYear(); // 년도
              var month = today.getMonth() + 1;  // 월
              var date = today.getDate();  // 날짜
              var day = today.getDay();
              var hours = today.getHours(); // 시
              var minutes = today.getMinutes();  // 분
              var seconds = today.getSeconds();  // 초
              var cam_photo_day2 = year + '.' + month + '.' + date + " " + hours + ':' + minutes + ':' + seconds;
       
              res.render('login_photo', {device_id: device_id, cam_photo_name1: cam_photo_name1, cam_photo_name2: cam_photo_name2, cam_photo_day1:cam_photo_day1,cam_photo_day2:cam_photo_day2 });
      
            });
          
            //const cam_photo_file_query = "SELECT * FROM cam_photo_file WHERE device_id = $1";
          /*  const cam_photo_file_query = "SELECT * FROM cam_photo_file order by photo_file_day DESC";
    
            dbClient.query(cam_photo_file_query).then(res4 => {
              console.log(res4.rows[0].photo_file_name)
              var cam_photo_name2 =  res4.rows[0].photo_file_name;
              var cam_photo_day2 =  res4.rows[0].photo_file_day;
              res.render('test_photo', {device_id: device_id, cam_photo_name1: cam_photo_name1, cam_photo_name2: cam_photo_name2, cam_photo_day1:cam_photo_day1,cam_photo_day2:cam_photo_day2 });
      
            });*/
          }
         });

        //dbClient.end();

      } else {
        console.log('0')
        res.redirect('/login');
        //dbClient.end();
      }
    });
    // dbClient.end();


  } else {
    res.redirect('/login');
  }
});

module.exports = router;

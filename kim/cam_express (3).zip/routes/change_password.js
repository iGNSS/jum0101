var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var path = require("path");
const bcrypt = require('bcrypt');


const { Client } = require("pg");


console.log("123")
router.get('/', function (req, res, next) {
  var userid = req.cookies.jsonid;
  if (userid != null) {
    res.render('change_password', { userid: userid.id });
  } else {
    res.redirect('/login');
  }
});

var idlen;
router.post('/', function (req, res) {
  var userid = req.cookies.jsonid;
  if (userid != null) {
    const dbClient = new Client({
      user: "minuk",
      host: "gw.nineone.com",
      database: "picmonitoring",
      password: "minuk7210",
      port: 5432
    });
    dbClient.connect(err => {
      if (err) {
        console.error('connection error', err.stack)
      } else {
        console.log('change_password!')
      }
    }); 
    var id = userid
    var pw = req.body.pw
    var cpw = req.body.cpw
    var bbb = req.body.overlap
    console.log(id)


    if (process.browser) {
      const name = document.getElementById('idd').value;
      document.getElementById("iderr").innerText = name;
      console.log(3)

    }

    if (id.length > 0 && cpw.length > 0) {

      const query = "SELECT * FROM cam_id_passward WHERE user_id = $1";
      const values = [id];
      dbClient.query(query, values).then(ress => {
        const data = ress.rows;
        var rows = [];
        if (data.length > 0) {
          data.forEach(row => {
            rows.push(row);
            console.log(row)
          });
          const post = ress.rows[0].user_passward;
          const postInString = JSON.stringify(post);
          console.log(post + "," + cpw);
          const match = bcrypt.compareSync(cpw, post);
          if (match) {
            console.log("비밀번호 있음");
            idlen = data.length;
            console.log(data + "," + data.length)
            if (data.length >= 1) {
              var expiryDate = new Date(Date.now() + 60 * 60 * 1000 * 24 * 7); // 24 hour 7일

              dbClient.end();
              // req.session.userid = userid;
              // var cookieLoginObj1 = req.cookies;
              // console.log(req.cookies.json)
              console.log("비번똑같음")
              res.send('<script type="text/javascript">alert("비밀번호가 전과 같습니다.");location.href  ="/change_password";</script>');

            } else {
              res.redirect('/loginsu?msg=등록되지 않은 사용자 입니다');
              console.log("로그인실패 아이디없음")
              //   dbClient.end();
            }
          } else {
            const hash = bcrypt.hashSync(cpw, 10);
            const sqlupload = `UPDATE cam_id_passward SET user_passward = $1 WHERE user_id = $2`;
            const sqluploadvalues = [hash, id];
            dbClient.query(sqlupload, sqluploadvalues, (err, res3) => {
              if (err) {
                dbClient.end();
                console.log(err.stack)
                //res.render('photo_change_move', { device_name: device_name });
              } else {

                dbClient.end();
                console.log(res3.rows[0])

                res.redirect('/loginsu?msg=변경완료');
              }

            });
            //   dbClient.end();
            // res.send('<script type="text/javascript">alert("로그인실패 아이디 또는 패스워드가 틀림");location.href  ="/login";</script>');
            // console.log("로그인실패 아이디 또는 패스워드가 틀림")
          }
        } else {
          //  dbClient.end();
          res.send('<script type="text/javascript">alert("아이디 없음");location.href  ="/login";</script>');
          console.log("아이디 없음")
        }

      });
    }
  } else {
    res.redirect('/login');
  }
});

function iderrmessge() {

  if (typeof document !== "undefined") {
    let x = document.getElementsByClassName("idd")[0];
    // x.innerText="Javascript"; 
    x.style.color = "red";
    document.getElementById('iderr').innerHTML = '아이디';
  }
  if (idlen >= 1) {
    if (typeof document !== "undefined") {
      document.getElementById('iderr').innerHTML = '아이디 중복';
    }
  } else {
    console.log("아이디 사용가능")
    if (typeof document !== "undefined") {
      document.getElementById('iderr').innerHTML = '아이디 사용가능';
    }

  }
}
router.get('/signup2', function (req, res, next) {
  //  console.log("3");
  res.render('signup2');
});
function checkPW() {
  //  $('#id').val();
  const id = req.body.idd
  const pw = req.body.pw
  const cpw = req.body.cpw
  console.log("r3");
  if (id.length == 0) {

  }
  else if (id.length < 2 || id.length >= 10) {
    alert("ID는 2~10글자");
  } else {
    `<script>
    alert('이메일 인증 시간을 초과했습니다.');
  
  </script>`
  }
}
module.exports = router;

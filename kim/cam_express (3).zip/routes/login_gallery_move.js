var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');
const url = require('url');
const fs = require('fs');
const cors = require('cors')
const session = require('express-session')
var cookieParser = require('cookie-parser');
router.use(cookieParser());
router.use(
  session({
    key: "loginData",
    secret: "testSecret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      expires: 60 * 60 * 24,
    },
  })
);

router.get('/', function (req, res, next) {
 
  var device_id = req.query.de_id;

  res.cookie('jsondevideID', {
    deviceid: device_id,
    name: 'mingyu',
    data: 100
  });
  res.render('login_gallery_move');
      
});

module.exports = router;

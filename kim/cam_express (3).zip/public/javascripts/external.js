function fnChangeString() {
    document.getElementById('content').innerHTML = '문자열을 변경합니다.';
}

function fnChangeFont() {
    document.getElementById('content').style.fontSize = '35px';
}

function fnChangeDisplayNone() {
    document.getElementById('content').style.display = 'none';
}

function fnChangeDisplayBlock() {
    document.getElementById('content').style.display = 'block';
}

function fnChangeImageChar() {
    document.getElementById('imgFgoChar').src = 'janedarc.png';
}

function fnChangeImageCharAlter() {
    document.getElementById('imgFgoChar').src = 'janedarc_alter.png';
}
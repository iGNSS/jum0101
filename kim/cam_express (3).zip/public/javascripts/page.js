jQuery(document).ready(function(){
    Galleria.loadTheme('/galleria/themes/classic/galleria.classic.min.js');
    Galleria.run('.galleria');
});